# CTI-110
# P4HW2 - Salary Calculator
# Kayla Smith
# 11/16/22
#


# Input
# Initialize employee count and total variables to 0.
# First input for employee name to begin while loop or terminate program.

employees = 0
totalOvertime = 0.0
totalRegPay = 0.0
totalGrossPay = 0.0
name = input("Enter employee's name or \"None\" to terminate >> ")

while name != "None":
    # Increment employee count, initialize overtime.
    employees += 1
    overtime = 0.0
    # Input for hours and rate.
    hours = float(input(f'How many hours did {name} work? >> '))
    rate = float(input('Enter pay rate >> '))

    # Processing
    # Determine if the employee has worked overtime, and if so, store the amount of overtime hours as a variable.
    # Calculate pay as the hours excluding overtime multiplied by the rate.
    # Calculate overtime pay as 1.5 times the rate, then multiply by overtime hours.

    if hours > 40:
        overtime = hours - 40
    regPay = (hours - overtime) * rate
    overtimePay = (1.5 * rate) * overtime

    # Calculate total variables.
    
    totalOvertime += overtimePay
    totalRegPay += regPay
    totalGrossPay += (regPay + overtimePay)

    # Output
    # Display employee name, hours worked, pay rate, overtime, overtime pay, regular hour pay, and gross pay.
    # Gross pay is calculated as pay + overtime pay.
    # Dollar amounts are formatted with two decimal points, and time amounts are formatted with one.

    print('')
    print(f'Employee name:    {name}')
    print('')
    print('Hours Worked    Pay Rate      OverTime          OverTime Pay        RegHour Pay     Gross Pay')
    print('-------------------------------------------------------------------------------------------------')
    print(f'{hours:.1f}            ${rate:.2f}         {overtime:.1f}              ${overtimePay:.2f}               ${regPay:.2f}         ${(regPay + overtimePay):.2f}')
    print('')

    # Input for next employee's name or terminate while loop.
    name = input("Enter employee's name or \"None\" to terminate >> ")

# Termination output, display total variables.
print('')
print(f'Total number of employees entered: {employees}')
print(f'Total amount paid for overtime: ${totalOvertime:.2f}')
print(f'Total amount paid for regular hours: ${totalRegPay:.2f}')
print(f'Total amount paid in gross: ${totalGrossPay:.2f}')
