# CTI-110
# P2HW2 - List
# Kayla Smith
# 10/10/22
#

# Input
# Input Module 1
# Input Module 2
# Input Module 3
# Input Module 4
# Input Module 5
# Input Module 6
# Set grades as a list containing all module grades

module1 = float(input('Enter your Module 1 grade > '))
module2 = float(input('Enter your Module 2 grade > '))
module3 = float(input('Enter your Module 3 grade > '))
module4 = float(input('Enter your Module 4 grade > '))
module5 = float(input('Enter your Module 5 grade > '))
module6 = float(input('Enter your Module 6 grade > '))
grades = [module1, module2, module3, module4, module5, module6]

# Calculations
# Set lowest to minimum number from grades
# Set highest to maximum number from grades
# Set total to the sum of grades
# Set average to the mean of grades

lowest = min(grades)
highest = max(grades)
total = sum(grades)
average = (sum(grades) / 6)

# Output
# Print results header
# Print lowest grade
# Print highest grade
# Print sum of grades
# Print average of grades
# Print results footer

print('------------Results------------')
print(f'Lowest grade:       {lowest:.2f}')
print(f'Highest grade:      {highest:.2f}')
print(f'Sum of grades:      {total:.2f}')
print(f'Average:            {average:.2f}')
print('-------------------------------')