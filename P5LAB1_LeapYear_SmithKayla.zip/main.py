# Function that determines the number of days in February for a given year.
def days_in_feb(n):
    if (n % 100) == 0:
        daysInFeb = 28
        if (n % 400) == 0:
            daysInFeb = 29
    elif (n % 4) == 0:
        daysInFeb = 29
    else:
        daysInFeb = 28
    return daysInFeb

# Input user year and output
if __name__ == '__main__':
    user_year = int(input())
    print(f'{user_year} has {days_in_feb(user_year)} days in February.')