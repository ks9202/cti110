#
# This program takes a number grade, determines average and displays letter grade for average.
# 10/26/2022
# CTI-110 P3HW1 - Debugging
# Kayla Smith
#

# Enter grades for six modules into a list

grades = []
grades.append(float(input('Enter grade for Module 1: ')))
grades.append(float(input('Enter grade for Module 2: ')))
grades.append(float(input('Enter grade for Module 3: ')))
grades.append(float(input('Enter grade for Module 4: ')))
grades.append(float(input('Enter grade for Module 5: ')))
grades.append(float(input('Enter grade for Module 6: ')))

# Determine and print lowest, highest, sum and average of grades
# Average is kept as a variable for use in the if else statement

avg = sum(grades) / len(grades)

print()
print('------------Results------------')
print(f'Lowest grade:       {(min(grades)):.1f}')
print(f'Highest grade:      {(max(grades)):.1f}')
print(f'Sum of grades:      {(sum(grades)):.1f}')
print(f'Average:            {avg:.2f}')
print('-------------------------------')

# Determine letter grade for average and display

if avg >= 90:
    print('Your grade is: A')
elif avg >= 80:
    print('Your grade is: B')
elif avg >= 70:
    print('Your grade is: C')
elif avg >= 60:
    print('Your grade is: D')
else:
    print('Your grade is: F')






