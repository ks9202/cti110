# A travel expenses calculator
# 9/21/2022
# CTI-110 P2HW1 - Travel
# Kayla Smith
#

# Input Float budget
# Input location
# Input Float gas
# Input Float accomodation
# Input Float food
# 
# Set total to gas + accomodation + food
# Set balance to budget - total
#
# Display blank
# Display travel expenses header
# Display location
# Display budget
# Display blank
# Display gas
# Display accomodation
# Display food
# Display blank
# Display balance

# Input
budget = float(input('Enter your budget > '))
location = input('Enter your travel destination > ')
gas = float(input('How much do you think you will spend on gas? > '))
accomodation = float(input('How much will you need for accomodation/hotel? > '))
food = float(input('How much will you spend on food? > '))
# Process
total = gas + accomodation + food
balance = budget - total
# Output
print()
print('------------Travel Expenses------------')
print(f'Location:           {location}')
print(f'Initial budget:     ${budget:.2f}')
print(f'Fuel:               ${gas:.2f}')
print(f'Accomodation:       ${accomodation:.2f}')
print(f'Food:               ${food:.2f}')
print('---------------------------------------')
print()
print(f'Remaining Balance:  ${balance:.2f}')