num1 = int(input())
num2 = int(input())

if num1 <= num2:
    print(num1, end = ' ')
    while (num1 + 5) <= num2:
        num1 += 5
        print(num1, end=' ')
    print("\n", end='')
else:
    print("Second integer can't be less than the first.")