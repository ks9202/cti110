# CTI-110
# P3HW2 - Salary
# Kayla Smith
# Date
#

# Input
# Initialize overtime hours to 0.0.
# Input for the employee's name, hours worked, and hourly rate.
# Both hours and rate are converted to float for calculations.

overtime = 0.0
name = input('Enter employee name >> ')
hours = float(input('Enter hours worked >> '))
rate = float(input('Enter pay rate >> '))

# Processing
# Determine if the employee has worked overtime, and if so, store the amount of overtime hours as a variable.
# Calculate pay as the hours excluding overtime multiplied by the rate.
# Calculate overtime pay as 1.5 times the rate, and then multiply that by overtime hours.

if hours > 40:
    overtime = hours - 40
pay = (hours - overtime) * rate
overtimePay = (1.5 * rate) * overtime

# Output
# Display employee name, hours worked, pay rate, overtime, overtime pay, regular hour pay, and gross pay.
# Gross pay is calculated as pay + overtime pay.
# Dollar amounts are formatted with two decimal points, and time amounts are formatted with one.

print('---------------------------------------')
print(f'Employee name:    {name}')
print('')
print('Hours Worked    Pay Rate      OverTime          OverTime Pay        RegHour Pay     Gross Pay')
print('-------------------------------------------------------------------------------------------------')
print(f'{hours:.1f}            ${rate:.2f}         {overtime:.1f}              ${overtimePay:.2f}             ${pay:.2f}         ${(pay + overtimePay):.2f}')
