# CTI-110
# P4HW1 - Score List
# Kayla Smith
# 11/14/22
#

# Initialize count and grades list
count = 1
grades = []

# Input
# Input number of grades to enter
# Input grades as a loop
# If invalid, state that input is invalid and ask user to input again

numGrades = int(input('Enter the number of grades >> '))
while count < (numGrades + 1):
    score = int(input(f'Enter score #{count} >> '))
    if (score >= 0) and (score <= 100):
        grades.append(score)
        count += 1
    else:
        while (score < 0) or (score > 100):
            print('')
            print('Invalid score entered.')
            print('Score should be between 0 and 100.')
            score = int(input(f'Enter score #{count} again >> '))
            if (score >= 0) and (score <= 100):
                grades.append(score)
                count += 1

# Calculations
# Store lowest grade as a variable for output
# Modify list to drop the lowest grade
# Store average as a variable
# Calculate letter grade

minGrade = min(grades)
grades.remove(minGrade)
average = (sum(grades) / len(grades))
if average >= 90:
    letterGrade = 'A'
elif average >= 80:
    letterGrade = 'B'
elif average >= 70:
    letterGrade = 'C'
elif average >= 60:
    letterGrade = 'D'
else:
    letterGrade = 'F'

# Output
# Print results header
# Print lowest grade, modified list, average, letter grade
# Print results footer

print('')
print('------------Results-----------------')
print(f'Lowest grade:       {minGrade:.2f}')
print(f'Modified list:      {grades}')
print(f'Average:            {average:.2f}')
print(f'Letter grade:       {letterGrade}')
print('------------------------------------')
